# hashcomp

A simple command line tool to check whether some files have the same sha256 checksum.

## Usage:

hashcomp.py [-h] FILE [...]
