# hashcomp

A simple command line tool to check whether some files have the same sha256 checksum.

## Usage:

`hashcomp [-h] FILE [...]`

## install

`git clone git@github.com:Lodobo/hashcomp.git`

`cd hashcomp`

`pip install dist/hashcomp-0.1.0-py3-none-any.whl`
